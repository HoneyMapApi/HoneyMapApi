
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Tervetuloa HoneyMap API:in!"}

@app.get("/data")
def get_data():
    return {
        "id": 1,
        "description": "Tämä on esimerkkidata GPS-jäljelle.",
        "coordinates": [[60.1695, 24.9354], [60.1700, 24.9360]]
    }
